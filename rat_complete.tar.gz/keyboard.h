#ifndef KEYBOARD_H
#define KEYBOARD_H

#include <windows.h>

/**
 * Starts global keyboard hook for macro recording automation.
 * Logs keyboard events to specified file for legitimate automation tools.
 * 
 * @param logPath Path to log file for recording macros
 * @return BOOL TRUE if hook installed successfully, FALSE otherwise
 */
BOOL StartKeyboardHook(const char* logPath);

/**
 * Stops keyboard hook and cleans up resources.
 * Should be called before program exit.
 */
void StopKeyboardHook();

#endif // KEYBOARD_H