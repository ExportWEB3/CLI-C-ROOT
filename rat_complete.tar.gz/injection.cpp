#include <windows.h>
#include <iostream>

/**
 * DLL injection helper for debugging tools.
 * Injects a monitoring DLL into target process for API hooking and debugging.
 * 
 * @param pid Target process ID
 * @param dllPath Full path to monitoring DLL
 * @return BOOL TRUE if injection successful, FALSE otherwise
 */
BOOL InjectDllIntoProcess(DWORD pid, const char* dllPath) {
    HANDLE hProcess = NULL;
    LPVOID pRemoteMem = NULL;
    HANDLE hRemoteThread = NULL;
    BOOL success = FALSE;
    
    // Step 1: Open target process with required permissions
    hProcess = OpenProcess(
        PROCESS_CREATE_THREAD | PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_QUERY_INFORMATION,
        FALSE,
        pid
    );
    
    if (hProcess == NULL) {
        std::cerr << "OpenProcess failed: " << GetLastError() << std::endl;
        return FALSE;
    }
    
    // Step 2: Calculate DLL path size
    SIZE_T dllPathSize = strlen(dllPath) + 1;
    
    // Step 3: Allocate memory in target process for DLL path
    pRemoteMem = VirtualAllocEx(
        hProcess,
        NULL,
        dllPathSize,
        MEM_COMMIT | MEM_RESERVE,
        PAGE_READWRITE
    );
    
    if (pRemoteMem == NULL) {
        std::cerr << "VirtualAllocEx failed: " << GetLastError() << std::endl;
        goto cleanup;
    }
    
    std::cout << "Allocated memory at: 0x" << std::hex << pRemoteMem << std::dec << std::endl;
    
    // Step 4: Write DLL path to allocated memory
    SIZE_T bytesWritten = 0;
    if (!WriteProcessMemory(
        hProcess,
        pRemoteMem,
        dllPath,
        dllPathSize,
        &bytesWritten
    )) {
        std::cerr << "WriteProcessMemory failed: " << GetLastError() << std::endl;
        goto cleanup;
    }
    
    if (bytesWritten != dllPathSize) {
        std::cerr << "Partial write: " << bytesWritten << " of " << dllPathSize << " bytes" << std::endl;
        goto cleanup;
    }
    
    std::cout << "Wrote DLL path to remote memory" << std::endl;
    
    // Step 5: Get LoadLibraryA address (same in all processes)
    HMODULE hKernel32 = GetModuleHandleA("kernel32.dll");
    if (hKernel32 == NULL) {
        std::cerr << "GetModuleHandleA failed: " << GetLastError() << std::endl;
        goto cleanup;
    }
    
    FARPROC pLoadLibraryA = GetProcAddress(hKernel32, "LoadLibraryA");
    if (pLoadLibraryA == NULL) {
        std::cerr << "GetProcAddress failed: " << GetLastError() << std::endl;
        goto cleanup;
    }
    
    // Step 6: Create remote thread to call LoadLibraryA with DLL path
    hRemoteThread = CreateRemoteThread(
        hProcess,
        NULL,
        0,
        (LPTHREAD_START_ROUTINE)pLoadLibraryA,
        pRemoteMem,
        0,
        NULL
    );
    
    if (hRemoteThread == NULL) {
        std::cerr << "CreateRemoteThread failed: " << GetLastError() << std::endl;
        goto cleanup;
    }
    
    std::cout << "Remote thread created" << std::endl;
    
    // Step 7: Wait for thread completion
    DWORD waitResult = WaitForSingleObject(hRemoteThread, 10000);
    if (waitResult != WAIT_OBJECT_0) {
        std::cerr << "WaitForSingleObject failed: " << GetLastError() << std::endl;
        goto cleanup;
    }
    
    // Step 8: Check if DLL loaded successfully
    DWORD exitCode = 0;
    if (!GetExitCodeThread(hRemoteThread, &exitCode)) {
        std::cerr << "GetExitCodeThread failed: " << GetLastError() << std::endl;
    } else if (exitCode == 0) {
        std::cerr << "LoadLibraryA failed in remote process" << std::endl;
        goto cleanup;
    } else {
        std::cout << "DLL loaded at address: 0x" << std::hex << exitCode << std::dec << std::endl;
    }
    
    success = TRUE;
    std::cout << "DLL injection successful for PID: " << pid << std::endl;
    
cleanup:
    // Clean up resources
    if (pRemoteMem != NULL) {
        VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
    }
    
    if (hRemoteThread != NULL) {
        CloseHandle(hRemoteThread);
    }
    
    if (hProcess != NULL) {
        CloseHandle(hProcess);
    }
    
    return success;
}
