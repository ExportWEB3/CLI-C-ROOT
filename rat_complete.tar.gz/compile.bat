@echo off
echo Compiling Windows Administration Tool...
echo.

REM Compile with MinGW (adjust paths as needed)
g++ -c injection.cpp -o injection.o -lpsapi
g++ -c persistence.cpp -o persistence.o -ladvapi32
g++ -c keyboard.cpp -o keyboard.o -luser32
g++ -c utils.cpp -o utils.o -lpsapi
g++ -c main.cpp -o main.o

REM Link everything together
g++ -o myapp.exe main.o injection.o persistence.o keyboard.o utils.o -lpsapi -ladvapi32 -luser32 -lkernel32

echo.
echo Compilation complete!
echo Executable: myapp.exe
echo.
pause