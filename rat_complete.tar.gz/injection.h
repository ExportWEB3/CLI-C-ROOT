#ifndef INJECTION_H
#define INJECTION_H

#include <windows.h>

/**
 * DLL injection helper for debugging tools.
 * Injects a monitoring DLL into target process for API hooking and debugging.
 * 
 * @param pid Target process ID
 * @param dllPath Full path to monitoring DLL
 * @return BOOL TRUE if injection successful, FALSE otherwise
 */
BOOL InjectDllIntoProcess(DWORD pid, const char* dllPath);

#endif // INJECTION_H