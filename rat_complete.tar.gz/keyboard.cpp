#include <windows.h>
#include <iostream>
#include <fstream>

// Global hook handle
HHOOK g_hKeyboardHook = NULL;
std::ofstream g_logFile;

/**
 * Low-level keyboard hook procedure for macro recording.
 * Logs keyboard events to a file for automation purposes.
 */
LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode >= 0) {
        KBDLLHOOKSTRUCT* pKeyInfo = (KBDLLHOOKSTRUCT*)lParam;
        
        // Log key events to file
        if (g_logFile.is_open()) {
            const char* eventType = "";
            if (wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN) {
                eventType = "KEYDOWN";
            } else if (wParam == WM_KEYUP || wParam == WM_SYSKEYUP) {
                eventType = "KEYUP";
            }
            
            // Log virtual key code and scan code
            g_logFile << eventType << " VK: " << pKeyInfo->vkCode 
                     << " Scan: " << pKeyInfo->scanCode 
                     << " Flags: " << pKeyInfo->flags << std::endl;
            
            // Flush to ensure data is written
            g_logFile.flush();
        }
        
        // Example: Detect Ctrl+C for macro recording
        if (pKeyInfo->vkCode == 'C' && (GetAsyncKeyState(VK_CONTROL) & 0x8000)) {
            std::cout << "Ctrl+C detected - could trigger macro" << std::endl;
        }
    }
    
    // Pass to next hook in chain
    return CallNextHookEx(g_hKeyboardHook, nCode, wParam, lParam);
}

/**
 * Starts global keyboard hook for macro recording automation.
 * 
 * @param logPath Path to log file for recording macros
 * @return BOOL TRUE if hook installed successfully, FALSE otherwise
 */
BOOL StartKeyboardHook(const char* logPath) {
    // Open log file for macro recording
    g_logFile.open(logPath, std::ios::app);
    if (!g_logFile.is_open()) {
        std::cerr << "Failed to open log file: " << logPath << std::endl;
        return FALSE;
    }
    
    g_logFile << "=== Macro recording started ===" << std::endl;
    
    // Install low-level keyboard hook
    g_hKeyboardHook = SetWindowsHookEx(
        WH_KEYBOARD_LL,             // Low-level keyboard hook type
        LowLevelKeyboardProc,       // Hook procedure
        GetModuleHandle(NULL),      // Instance handle
        0                           // Thread ID (0 = global)
    );
    
    if (g_hKeyboardHook == NULL) {
        std::cerr << "SetWindowsHookEx failed: " << GetLastError() << std::endl;
        g_logFile.close();
        return FALSE;
    }
    
    std::cout << "Keyboard hook installed. Recording macros to " << logPath << std::endl;
    std::cout << "Press Ctrl+Q to exit" << std::endl;
    return TRUE;
}

/**
 * Stops keyboard hook and cleans up resources.
 */
void StopKeyboardHook() {
    if (g_hKeyboardHook != NULL) {
        UnhookWindowsHookEx(g_hKeyboardHook);
        g_hKeyboardHook = NULL;
        std::cout << "Keyboard hook removed" << std::endl;
    }
    
    if (g_logFile.is_open()) {
        g_logFile << "=== Macro recording stopped ===" << std::endl;
        g_logFile.close();
    }
}

